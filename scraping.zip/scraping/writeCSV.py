#A writer object lets you write data to a CSV file. To create a writer object, you use the csv.writer() function.
import csv
#First, call open() and pass it 'w' to open a file in write mode ➊. This will create the object you can then pass to csv.writer() to create a writer object.
outputFile = open('output.csv','w',newline='') #If you forget the newline='' keyword argument in open(), the CSV file will be double-spaced.
outputWriter = csv.writer(outputFile)
outputWriter.writerow(['spam','eggs','bacon','ham'])
print(outputWriter)
outputFile.close()

'''
The delimiter and lineterminator Keyword Arguments
'''
#if you want to separate cells with a tab character instead of a comma and you want the rows to be double-spaced.
import csv
csvFile = open('example.csv','w',newline='')
csvWriter = csv.writer(csvFile,delimiter='\t',lineterminator='\n\n')
csvWriter.writerow(['apples','oranges','grapes'])
csvWriter.writerow(['eggs', 'bacon', 'ham'])
csvFile.close()

import csv
exampleFile = open('/home/splendornet/scrap/scraping/site1/data.csv')
exampleDictReader = csv.DictReader(exampleFile,['id','weight','display_name'])
for row in exampleDictReader:
    print(row['id'],row['weight'],row['display_name'])
