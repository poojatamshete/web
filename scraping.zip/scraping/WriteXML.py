# xml is object name  and xml.etree.ElementTree  is namespace
import xml.etree.ElementTree as xml
def GenerateXML(filename):
    # create root element
    root = xml.Element("Customers")
    #create chlid elements
    c = xml.Element('customer')
    #add child to the root
    root.append(c)
    #add some values or subchilds
    type1 = xml.SubElement(c,"place") # place is tagname
    type1.text = "UK" # content in type1 tag
    Amount = xml.SubElement(c,"Amount")
    Amount.text = "5000"
    # add all alents to tree
    tree = xml.ElementTree(root)
    with open(filename,"wb") as files:
        #writing data created in tree
        tree.write(files)

# now invoking function
if __name__=="__main__":
    GenerateXML("Customers.xml")#if you do nat mention path it will craeted where your code



