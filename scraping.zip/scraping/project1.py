#!python
import csv, os
os.makedirs('headerREmoved',exist_ok=True)
#loop through every file in the current working directory
for csvFilename in os.listdir('.'):
    if not csvFilename.endswith('.csv'):
        continue

    print('Removing header from' + csvFilename+'...')
