# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class Site1Item(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    head = scrapy.Field()
    brand = scrapy.Field()
    description = scrapy.Field()
    id = scrapy.Field()
    product_name = scrapy.Field()
    display_name = scrapy.Field()
    info_name = scrapy.Field()
    uPC = scrapy.Field()
    mfr = scrapy.Field()
    weight = scrapy.Field()


