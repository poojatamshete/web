import scrapy
from ..items import Site1Item

class Site1Spider(scrapy.Spider):
    name = "site1"
    start_urls= [
            'https://www.rjmatthews.com/',
        ]
    def parse(self,response):
        next_page = response.css('li.primary-nav__item a::attr(href)').extract()
        #print(next_page)
        for next_pages in next_page:
            yield scrapy.Request(response.urljoin(next_pages), callback=self.parse1)
    def parse1(self,response):
        next_page1 = response.css('li.secondary-nav__item--has-children a::attr(href)').extract()
        #print(next_page1)
        for next_pages1 in next_page1:
             yield scrapy.Request(response.urljoin(next_pages1), callback=self.parse2)

    def parse2(self,response):
        next_page2 = response.css("p.product-summary__name a::attr(href)").extract()
        #print(next_page2)
        for next_pages2 in next_page2:

            yield scrapy.Request(response.urljoin(next_pages2), callback=self.parse3)

    def parse3(self, response):
        items = Site1Item()
        print("---------------------------------------------------------------------------------------------------")
        #print(response)
        id1=[]
        new2 = []
        all_div = response.css("div.product-details__name")
        for quotes in all_div:
            head = quotes.css('h1.product-details__title::text').extract()
            brand = quotes.css('a.product-details__brand::text').extract()
            id = quotes.css('p.product-details__id span::text').extract()
            #id1.append(id)
            description = response.css('div.product-details__description p::text').extract()
            items['id'] = id
            items['head'] = head
            items['brand'] = brand
            items['description'] = description
            yield items
            varients_list = response.css('ul.variant-list')
            varients = varients_list.css('li.variant-list__item')
            for var in varients:
                product_name = var.css('div.variant-list__name div.variant-list__product-name::text').extract()
                display_name = var.css('div.variant-list__name div.variant-list__display-name::text').extract()
                info_name = var.css('div.variant-list__note::text').extract()
                new = product_name + display_name + info_name
                for i in product_name:
                    items['product_name'] = product_name
                    items['display_name'] = display_name
                    #print(info_name[:1])
                    items['id'] = info_name[0][8:]
                    #items['info_name']=info_name
                    items['uPC']=info_name[1][6:]
                    items['mfr']=info_name[2][7:]
                    items['weight']=info_name[5][8:]
                    yield items

            #for list1 in varients_list:
