# here ET is an object you can give another name to it
import xml.etree.ElementTree as ET
# tree contains all the xml information. tree is a variable
tree = ET.parse("/home/splendornet/scrap/scraping/site1/data.xml")
# to get root informataion use getrroot, now rooot variable contains root object.
root = tree.getroot()
print(root)
#if you want to print roottag name
tag = root.tag
print(tag)
attribute = root.attrib
print(attribute) # you will only get collection not whole content

print(len(root))# count the number of elements in root

for c in root.findall('item'): #here in findall item is element in root(items)
    #print(c) # here we get all elements in object form
    try:
        secondary_id = c.find('id') # this will create an object
        secondary_id = c.find('id').text # this will give the content or value inside that tag
        print(secondary_id)
    except:
        continue
    for d in c.findall('id'): # to extract all id
         try:
            e = d.find('value').text # getting text in value tag
            print(e)
         except:
             continue

    for f in c.findall('head'):
        try:
            g = f.find('value').text
            print(g)
        except:
            continue

    for h in c.findall('brand'):
        try:
            i = h.find('value').text
            print(i)
        except:
            continue

    for j in c.findall('description'):
        try:
            k = j.find('value').text
            print(k)
        except:
            continue
# and so on to extract tags inside another tag use for loops and you will get output of it.

















