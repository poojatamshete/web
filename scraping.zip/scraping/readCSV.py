import csv
exampleFile = open('/home/splendornet/scrap/scraping/site1/data.csv')
#To read data from a CSV file with the csv module, you need to create a reader object. A reader object lets you iterate over lines in the CSV file.
exampleReader = csv.reader(exampleFile) #
exampleData = list(exampleReader)
#print(exampleData)
#you can access the value at a particular row and column with the expression exampleData[row][col]
print(exampleData[0][2])

#For large CSV files, you’ll want to use the reader object in a for loop. This avoids loading the entire file into memory at once.
for row in exampleData:
    #getting each row,To get the row number, use the reader object’s line_num variable, which contains the number of the current line.
    print('Row #'+str(exampleReader.line_num)+''+str(row))
#The reader object can be looped over only once. To reread the CSV file, you must call csv.reader to create a reader object.

