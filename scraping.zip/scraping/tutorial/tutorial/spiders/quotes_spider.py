import scrapy
from ..items import TutorialItem

class QuotesSpider(scrapy.Spider):
    name = 'quotes'
    start_urls = [
        'http://quotes.toscrape.com/'
    ]

    def parse(self, response):
        items = TutorialItem()
        all_div_quotes = response.css("div.quote")

        for quotes in all_div_quotes:
            title = quotes.css('span.text::text').extract()
            author = quotes.css('.author::text').extract()
            tag = quotes.css('.tag::text').extract()

            items['title']=title
            items['author']=author
            items['tag']=tag
            yield items

        next_page = response.css('li.next a::attr(href)').get()
        if next_page is not None:
            yield response.follow(next_page, callback=self.parse)


















# import scrapy
#
#
# class QuotesSpider(scrapy.Spider):
#     name = "quotes"
#
#     def start_requests(self):
#         urls = [
#             'http://quotes.toscrape.com/page/1/',
#             'http://quotes.toscrape.com/page/2/',
#         ]
#         for url in urls:
#             yield scrapy.Request(url=url, callback=self.parse)
#
#     def parse(self, response):
#         for quote in response.css('div.quote'):
#             yield {
#                 'text':quote.css('span.text::text').get(),
#                 'author':quote.css('small.author::text').get(),
#                 'tags':quote.css('div.tags a.tags::text').getall(),
#             }
#         next_page = response.css('li.next a::attr(href)').get()
#         if next_page is not None:
#             next_page = response.urljoin(next_page)
#             yield scrapy.Request(next_page,callback=self.parse)
#
#
#         # page = response.url.split("/")[-2]
#         # filename = b'quotes-{page}.html'
#         # with open(filename, 'wb') as f:
#         #     f.write(response.body)
#         # self.log(b'Saved file {filename}')