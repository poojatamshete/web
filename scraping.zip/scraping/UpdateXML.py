# obj is object name  and xml.etree.ElementTree  is namespace
import xml.etree.ElementTree as obj

def UpdateXML(filename):
    tree = obj.ElementTree(file = filename)
    root = tree.getroot() # get add data in root

    for amounts in root.iter("Amount"): # iterate though all the amount column
        amounts.text = "50000" # assign value for every record

    tree = obj.ElementTree(root)
    with open(filename,"wb") as fileupdate:
        tree.write(fileupdate) #updationg the values

# invoke the function
if __name__=="__main__":
    UpdateXML("Customers.xml")