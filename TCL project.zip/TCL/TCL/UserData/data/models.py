from django.db import models

# Create your models here.
class Employee(models.Model):
    Account = models.CharField(max_length=100)
    Configuration_item = models.CharField(max_length=100)
    Product_name = models.CharField(max_length=100)
    CUID = models.IntegerField()
    email =models.EmailField(max_length=100)

    class Meta:
        db_table = "employee"