from django import forms
from .models import Employee
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField
from django.forms import ModelForm
from django.contrib.auth.models import User
from django.utils.translation import gettext, gettext_lazy as _

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = ['Account','Configuration_item','Product_name','CUID','email']
        #labels = {'Account':'Account','Configuration_item':'Configuration_item','Product_name':'Product_name','CUID':'CUID','email':'Email'}
        widgets={'Account':forms.TextInput(attrs={'class':'form-control'}),
                 'Configuration_item': forms.TextInput(attrs={'class': 'form-control'}),
                 'Product_name': forms.TextInput(attrs={'class': 'form-control'}),
                 'CUID': forms.NumberInput(attrs={'class': 'form-control'}),
                 'email': forms.EmailInput(attrs={'class': 'form-control'}),
                }

